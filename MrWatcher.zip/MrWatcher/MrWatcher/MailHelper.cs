﻿
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace MrWatcher
{
    internal class MailHelper
    {
        public static string GetConfigurationValue(string key)
        {
            var value = ConfigurationManager.AppSettings[key];
            Service.W("GetConfigurationValue [" + key + "][" + value + "]");
            return value;
        }


        public static void SendMail(string subject, string body)
        {
            try
            {
                priSendMail(subject, body);
            }
            catch (Exception ex)
            {
                Service.WriteLog("Error while sending mail. " + ex.Message);
            }
        }

        private static void priSendMail(string subject, string body)
        {

            string host = GetConfigurationValue("SmtpClient.Host");
            int port = Convert.ToInt32(GetConfigurationValue("SmtpClient.Port"));
            bool enableSsl = Convert.ToBoolean(GetConfigurationValue("SmtpClient.EnableSsl"));
            string username = GetConfigurationValue("SmtpClient.Username");
            string password = GetConfigurationValue("SmtpClient.Password");
            string from = GetConfigurationValue("Mail.From");
            string to = GetConfigurationValue("Mail.To");

            subject = subject.Replace("{replace}", DateTime.Now.ToString("dd.MM.yyyy HH:mm"));
            body = body.Replace("{replace}", DateTime.Now.ToString("dd.MM.yyyy HH:mm"));

            using (MailMessage mail = new MailMessage())
            {
                mail.From = new MailAddress(from);
                mail.To.Add(to);
                mail.Subject = subject;
                mail.Body = body;
                mail.IsBodyHtml = false;

                using (SmtpClient smtp = new SmtpClient(host, port))
                {
                    if (!string.IsNullOrWhiteSpace(username))
                    {
                        smtp.Credentials = new NetworkCredential(username, password);
                    }

                    smtp.EnableSsl = enableSsl;
                    Service.WriteLog("Send mail to:" + to);
                    smtp.Send(mail);
                }
            }

        }
    }
}
