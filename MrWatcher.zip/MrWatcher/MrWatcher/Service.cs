﻿using System;
using System.ServiceProcess;
using System.Text;
using System.IO;
using System.Reflection;

namespace MrWatcher
{
    public partial class Service : ServiceBase
    {
        const int SERVICE_ACCEPT_PRESHUTDOWN = 0x100;
        const int SERVICE_CONTROL_PRESHUTDOWN = 0xf;

        public Service()
        {
            InitializeComponent();
            CanHandleSessionChangeEvent = true;

            FieldInfo acceptedCommandsFieldInfo = typeof(ServiceBase).GetField("acceptedCommands", BindingFlags.Instance | BindingFlags.NonPublic);
            if (acceptedCommandsFieldInfo != null)
            {
                int value = (int)acceptedCommandsFieldInfo.GetValue(this);
                acceptedCommandsFieldInfo.SetValue(this, value | SERVICE_ACCEPT_PRESHUTDOWN);
            }
            else
            {
                WriteLog("AcceptedCommands field not found. Pre-shutdown not working");
            }
        }

        protected override void OnCustomCommand(int command)
        {
            W("CustomCommand " + command);

            if (command == SERVICE_CONTROL_PRESHUTDOWN)
            {
                WriteLog("Pre-shutdown");
                bool mailSendingEnabled = Convert.ToBoolean(MailHelper.GetConfigurationValue("MailSendingEnabled"));
                if (mailSendingEnabled)
                {
                    string subject = MailHelper.GetConfigurationValue("Mail.Stop.Subject");
                    string body = MailHelper.GetConfigurationValue("Mail.Stop.Body");
                    MailHelper.SendMail(subject, body);
                }
            }
            else
            {
                base.OnCustomCommand(command);
            }

        }

        public static void W(object s)
        {
            System.Diagnostics.Debug.WriteLine("[MrWatcher][Debug] " + s);
        }


        protected override void OnSessionChange(SessionChangeDescription changeDescription)
        {
            //W("OnSessionChange " + changeDescription.Reason + ", " + changeDescription.SessionId + "," + changeDescription.ToString());
            base.OnSessionChange(changeDescription);
        }
        protected override void OnStart(string[] args)
        {
            W("Start");
            WriteLog("Start");

            bool mailSendingEnabled = Convert.ToBoolean(MailHelper.GetConfigurationValue("MailSendingEnabled"));
            WriteLog("MailSendingEnabled=" + mailSendingEnabled);

            if (mailSendingEnabled)
            {
                string subject = MailHelper.GetConfigurationValue("Mail.Start.Subject");
                string body = MailHelper.GetConfigurationValue("Mail.Start.Body");
                MailHelper.SendMail(subject, body);
            }

            bool bln = Environment.HasShutdownStarted;
        }

        protected override void OnStop()
        {
            W("Stop");
            WriteLog("Stop");
        }

        protected override void OnShutdown()
        {
            W("Shutdown");
            WriteLog("Shutdown");

            base.OnShutdown();
        }

        internal static void WriteLog(string text)
        {
            try
            {
                string path = MailHelper.GetConfigurationValue("LogPath");
                if (!path.EndsWith(@"\")) { path = path + @"\"; }
                path = path + "MrWatcher_" + DateTime.Now.ToString("yyyyMMdd") + ".log";

                File.AppendAllText(path, DateTime.Now + " " + text + Environment.NewLine, Encoding.UTF8);
            }
            catch (Exception ex)
            {
                W("Error while writing log. " + ex.Message);
            }
        }
    }
}

