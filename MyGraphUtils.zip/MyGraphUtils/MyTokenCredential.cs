﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Azure.Core;

namespace MyGraphUtils
{
    public class MyTokenCredential : TokenCredential
    {


        public MyTokenCredential(AccessToken accessToken) 
        {
            AccessToken = accessToken;
        }

        public AccessToken AccessToken { set; get; }

        public override AccessToken GetToken(TokenRequestContext requestContext, CancellationToken cancellationToken)
        {
            return GetTokenAsync(requestContext, cancellationToken).Result;
        }

        public override ValueTask<AccessToken> GetTokenAsync(TokenRequestContext requestContext, CancellationToken cancellationToken)
        {
            

            if (String.IsNullOrWhiteSpace(AccessToken.Token)) { throw new Exception("AccessToken is not set"); }
            if (AccessToken.ExpiresOn < new DateTimeOffset(DateTime.Now)) { throw new Exception("AccessToken is expired " + AccessToken.ExpiresOn); }

            return new ValueTask<AccessToken>(AccessToken);
        }

    }
}
