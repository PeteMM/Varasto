﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyGraphUtils
{
    public class MyHttpClient
    {
        private static HttpClient _httpClient = new HttpClient();

        public static async Task<string> SendRequest(string url, HttpRequestMessage msg)
        {
            var response = await _httpClient.SendAsync(msg);
            return await response.Content.ReadAsStringAsync();
        }

        public static async Task<string> TokenRequest(string url, string body)
        {
            HttpRequestMessage msg = new HttpRequestMessage();
            msg.RequestUri = new Uri(url);
            msg.Method = HttpMethod.Post;
            msg.Content = new StringContent(body, Encoding.UTF8, "application/x-www-form-urlencoded");

            return await SendRequest(url, msg);
        }
    }
}
