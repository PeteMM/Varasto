﻿using Newtonsoft.Json;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using Org.BouncyCastle.Security;
using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.Asn1.Pkcs;
using Org.BouncyCastle.Utilities.IO.Pem;
using System.IdentityModel.Tokens.Jwt;
using Newtonsoft.Json.Linq;
using Org.BouncyCastle.Asn1.Ocsp;
using System.Runtime.ConstrainedExecution;
using System.IO;
using System.Web;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace MyGraphUtils
{
    //2023/10/19 PM
    public class Helper
    {
        public static void W(object s) {
            Console.WriteLine(s);
        }

        public static void Test()
        {
            //string pem = File.ReadAllText(@"E:\Projects\ConsoleAppCAPolicyTest1\kv-core-dev-westeu-pmtestcert-api-20230130.pem", Encoding.UTF8);
            string pem = File.ReadAllText(@"E:\Projects\ConsoleAppCAPolicyTest1\kv-osbu-dev-capolicydocappcert-20231017.pem",Encoding.UTF8);
            //string pem = File.ReadAllText(@"E:\Projects\ConsoleAppCAPolicyTest1\kv-osbu-dev-capolicydocappcert-publickey-20231017.pem", Encoding.UTF8);
            string tenantId = "eff5cd98-34f4-4298-85c0-399c9ffec3f0";
            string clientId = "4cd2eb63-bc33-4b1e-af69-9103af6604a1";
            string clientSecret = "hs.8Q~YHc.qgHJRvczrqw_.atPu.KhPgQo9dlcrd";
            int expSeconds = 60;


            //ExportPublicKey(pem, null, @"E:\Projects\ConsoleAppCAPolicyTest1\pk_test.pem");

            //W(GetTokenRequestBody(pem, tenantId, clientId, 60, "kissa"));
            //string client_assertion = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsIng1dCI6ImRaaTYtVXdpZzRWT2hPVjRHQzZUVm9CeXowTSJ9.eyJhdWQiOiJodHRwczovL2xvZ2luLm1pY3Jvc29mdG9ubGluZS5jb20vZWZmNWNkOTgtMzRmNC00Mjk4LTg1YzAtMzk5YzlmZmVjM2YwL29hdXRoMi92Mi4wL3Rva2VuIiwiZXhwIjoxNjk3NzExNTE3LCJpc3MiOiI0Y2QyZWI2My1iYzMzLTRiMWUtYWY2OS05MTAzYWY2NjA0YTEiLCJqdGkiOiJraXNzYSIsIm5iZiI6MTY5NzcxMTQ1Nywic3ViIjoiNGNkMmViNjMtYmMzMy00YjFlLWFmNjktOTEwM2FmNjYwNGExIiwiaWF0IjoxNjk3NzExNDU3fQ.E4o9We9voR_o8BmvsQ6f8MrYYkZhzEGmvLgCSCN5eXLpE1_YC5Dp2jxCVLLo_bftYpO-hTTar9-e8WbVfgTg6P66x_3p4c7vxqJcH-eA8zl-QqrijephHoMGgM7_MMAhIfo9FBCAvsoLrDj34kn5GzODcmEklnViKqoehx_dxCJOqyhgdnqI1sLV0ZN15w9Vn4Z_en3YiaUyAGcG4msMda8tKHZSHGPVRV3eLKLrmt-dZzwNmrsad_nbjpabfgpPLreqijOL3N-Qz8J317jsrSrHH082oQREeG3mkOMvRJAoMnXT9taziR8Nn86Cwarp8lB5nxIPpsiwZZ45_14OGw";
            //JwtSecurityToken t = new JwtSecurityToken(client_assertion);
            //bool bln = IsValidSignature(t, pem, Encoding.UTF8);
            //W("IsValidSignature:" + bln);
            //return;

            //string[] arr = client_assertion.Split('.');
            //bool bln = IsValidSignature(arr[0] + "." + arr[1], arr[2], pem, Encoding.UTF8);
            //JwtSecurityToken token = TokenRequest(tenantId, clientId, clientSecret).Result;
            //JwtSecurityToken token = TokenRequest(pem,tenantId, clientId, 60,null).Result;
            //W(token.RawData);

            //string body = GetTokenBody(pem,tenantId,clientId,60, null);
            //var results = MyHttpClient.TokenRequest("https://login.microsoftonline.com/eff5cd98-34f4-4298-85c0-399c9ffec3f0/oauth2/v2.0/token", body).Result;
            //W(results);

            //var privateKeyBytes = GetPrivateKey(pem, Encoding.UTF8);
            //W(Encoding.UTF8.GetString(privateKeyBytes));


            //var x509 = PublicKeyPemToX509(pem, Encoding.UTF8);
            //byte[] results = x509.GetPublicKey();
            //byte[] bytes = GetPuplicKey(x509);
            //string s = Encoding.UTF8.GetString(bytes);
            //W(s);
            //File.WriteAllBytes(@"E:\Projects\ConsoleAppCAPolicyTest1\pk_test2.pem", results);
            //foreach (byte b in results)
            //{
            //    Console.Write(b);
            //}


            //var x509 = PemToX509(pem, true, Encoding.UTF8);
            //W(X509ToPem(x509));
            //char[] pubKeyPem = PemEncoding.Write("PUBLIC KEY", x509.GetPublicKey());
            //File.WriteAllBytes(@"E:\Projects\ConsoleAppCAPolicyTest1\pk_test2.pem", Encoding.Unicode.GetBytes(pubKeyPem));
            //ExportPublicKey(pem, null, @"E:\Projects\ConsoleAppCAPolicyTest1\pk_test4.pem", null,true);


            //byte[] publicKeyBytes = GetPuplicKeyPemEncoding(pem, null);
            //W(GetPemPublicKey(pem, null));

            //byte[] publicKeyBytes = ;
            //W(Encoding.UTF8.GetString(publicKeyBytes));

            //
            //byte[] bytes = GetPuplicKeyPemEncoding(x509, null);
            //string pem2 = Encoding.Unicode.GetString(bytes);
            //W(pem2);

            //X509Certificate2 cert = PemToX509(pem, true, Encoding.UTF8);
            //string c = cert.ExportCertificatePem();
            //AsymmetricAlgorithm key = cert.GetRSAPrivateKey();
            //W(key.ExportSubjectPublicKeyInfoPem());

            //byte[] pubKeyBytes = key.ExportSubjectPublicKeyInfoPem();
            //File.WriteAllBytes(@"E:\Projects\ConsoleAppCAPolicyTest1\pk_test2.pem", pubKeyBytes);

            //string pubKeyPem = key.ExportSubjectPublicKeyInfoPem();
            //W(c);

            string pemPublicKey = File.ReadAllText(@"E:\Projects\ConsoleAppCAPolicyTest1\testpublickey2.pem",Encoding.UTF8);
     

            string stringToSign = "http://kissa?a=1";


            string signature2Base64UrlEncoded = SignBase64(stringToSign, null, pem, null, true);
            string signature2Base64 = Convert.ToBase64String(Base64UrlDecode(signature2Base64UrlEncoded));
            //W(HttpUtility.UrlDecode(signature2Base64));
            //W(IsValidSignature(stringToSign, signature2Base64, pem, null));

            //W(signature1);
            //W("");
            //W(HttpUtility.UrlDecode(signature2));
            //W(IsValidSignature(stringToSign,HttpUtility.UrlDecode(signature2), pem, null));

            string signature1Base64 = SignBase64(stringToSign, null, pem, null, false);
            W(IsValidSignatureByPublicKey(stringToSign, signature1Base64, pemPublicKey, Encoding.UTF8));


        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="signedString"></param>
        /// <param name="base64EncodedSignature"></param>
        /// <param name="pemPublicKey">PublicKey as pem format</param>
        /// <param name="encoding"></param>
        /// <returns></returns>
        public static bool IsValidSignatureByPublicKey(string signedString, string base64EncodedSignature, string pemPublicKey, Encoding? encoding)
        {
            if (encoding == null) { encoding = Encoding.UTF8; }

            pemPublicKey = pemPublicKey.Replace("-----BEGIN PUBLIC KEY-----", "");
            pemPublicKey = pemPublicKey.Replace("-----END PUBLIC KEY-----", "");
            //pemPublicKey = pemPublicKey.Replace("\n\r", "");

            RSA rsa = RSA.Create();
            byte[] publicKeyBytes = Convert.FromBase64String(pemPublicKey);
            rsa.ImportSubjectPublicKeyInfo(publicKeyBytes, out _);

            byte[] signatureBytes = Convert.FromBase64String(base64EncodedSignature);
            byte[] singnedBytes = encoding.GetBytes(signedString);
            return rsa.VerifyData(singnedBytes, signatureBytes, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
        }

        /// <summary>
        /// </summary>
        /// <param name="signedString"></param>
        /// <param name="base64EncodedSignature"></param>
        /// <param name="pemCertificate">Pem certificate.</param>
        /// <param name="encoding"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public static bool IsValidSignature(string signedString,string base64EncodedSignature, string pemCertificate, Encoding? encoding) {
            // sample
            // string stringToSign = "http://kissa?a=1";
            // string signature1Base64 = SignBase64(stringToSign, null, pem, null, false);
            // W(IsValidSignature(stringToSign, signature1Base64, pem, null));

            // string signature2Base64UrlEncoded = SignBase64(stringToSign, null, pem, null, true);
            // string signature2Base64 = Convert.ToBase64String(Base64UrlDecode(signature2Base64UrlEncoded));
            // W(IsValidSignature(stringToSign, signature2Base64, pem, null));


            if (encoding == null) { encoding = Encoding.UTF8; }
            X509Certificate2 cert = PemToX509(pemCertificate, false, encoding);

            var publicKey = cert.GetRSAPublicKey();
            if (publicKey == null) { throw new Exception("Certificate has not public key"); }


            using (RSA rsa = publicKey)
            {
                byte[] singnedBytes = encoding.GetBytes(signedString);
                byte[] signatureBytes = Convert.FromBase64String(base64EncodedSignature);//Base64UrlDecode(base64UrlEncodedSignature);
                return rsa.VerifyData(singnedBytes, signatureBytes, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
            }
        }

        /// <summary>
        /// Validate signature only (no claims validation include).   
        /// </summary>
        public static bool IsValidSignature(JwtSecurityToken token, string pemCertificate, Encoding? encoding) 
        {
            if (encoding == null) { encoding = Encoding.UTF8; }
            X509Certificate2 cert = PemToX509(pemCertificate, false, encoding);

            var publicKey = cert.GetRSAPublicKey();
            if (publicKey == null) { throw new Exception("Certificate has not public key"); }

            using (RSA rsa = publicKey)
            {
                string signedString = token.RawHeader + "." + token.RawPayload;
                byte[] singnedBytes = encoding.GetBytes(signedString);

                if (string.IsNullOrWhiteSpace(token.RawSignature)) { throw new Exception("JWT token is not signed"); }

                byte[] signatureBytes = Base64UrlDecode(token.RawSignature);

                return rsa.VerifyData(singnedBytes, signatureBytes, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
            }
        }

        public static void ExportPublicKey(string pem, Encoding? pemEncoding, string path, Encoding? fileEncoding, bool overwrite)
        {
            if (pemEncoding == null) { pemEncoding = Encoding.UTF8; }
            X509Certificate2 cert = PemToX509(pem, false, pemEncoding);
            ExportPublicKey(cert, path, fileEncoding, overwrite);
        }

        public static void ExportPublicKey(X509Certificate2 cert, string path, Encoding? encoding, bool overwrite)
        {
            var publicKey = cert.GetRSAPublicKey();
            if (publicKey == null) { throw new Exception("Public key not found"); }

            if (encoding == null) { encoding = Encoding.UTF8; }
            if (!overwrite && File.Exists(path)) { throw new Exception("File " + path + " already exists"); }
            File.WriteAllText(path, publicKey.ExportSubjectPublicKeyInfoPem(), encoding);
        }

        public static X509Certificate2 PemToX509(string pem,bool includePrivateKey, Encoding? encoding)
        {
            if (encoding == null) { encoding = Encoding.UTF8; }

            if (includePrivateKey)
            {
                if (!HasPrivateKey(pem, encoding)) { throw new Exception("Private key not found"); }

                byte[] certificateBytes = GetCertificate(pem, encoding);
                byte[] privatekeyeBytes = GetPrivateKey(pem, encoding);
                //X509Certificate2 x509 = X509Certificate2.CreateFromPem(
                //    Encoding.UTF8.GetString(certificateBytes).ToCharArray(),
                //    Encoding.UTF8.GetString(privatekeyeBytes).ToCharArray());
                X509Certificate2 x509 = X509Certificate2.CreateFromPem(
                    encoding.GetString(certificateBytes).ToCharArray(),
                    encoding.GetString(privatekeyeBytes).ToCharArray());
                return x509;
            }
            else {
                byte[] certificateBytes = GetCertificate(pem, encoding);
                X509Certificate2 x509 = X509Certificate2.CreateFromPem(encoding.GetString(certificateBytes).ToCharArray());
                return x509;
            }
        }

        public static string GetPemPublicKey(string pem, Encoding? encoding)
        {
            if (encoding == null) { encoding = Encoding.UTF8; }
    
            X509Certificate2 cert = PemToX509(pem,false, encoding);
            return GetPemPublicKey(cert);
        }

        public static string GetPemPublicKey(X509Certificate2 cert) {
            var publicKey = cert.GetRSAPublicKey();
            if (publicKey == null) { throw new Exception("Public key not found"); }
            return publicKey.ExportSubjectPublicKeyInfoPem();

            //byte[] pubKeyBytes = cert.GetPublicKey();
            //char[] pubKeyPem = PemEncoding.Write("PUBLIC KEY", pubKeyBytes);
            //var bytes = encoding.GetBytes(pubKeyPem);
            //return bytes;
        }


        public static bool HasPrivateKey(string pem, Encoding encoding) 
        {
            string header = "-----BEGIN PRIVATE KEY-----";
            string footer = "-----END PRIVATE KEY-----";

            bool bln = false;
            int a = pem.IndexOf(header);
            int b = pem.IndexOf(footer);

       

            return (a > -1 && b > -1) ? true : false;
        }




        public static byte[] GetPrivateKey(string pem, Encoding encoding)
        {
            if (encoding == null) { encoding = Encoding.ASCII; }

            string header = "-----BEGIN PRIVATE KEY-----";
            string footer = "-----END PRIVATE KEY-----";

            int a = pem.IndexOf(header);
            if (a == -1) { throw new Exception("Invalid pem file. Header " + header + " not found."); }
            int b = pem.IndexOf(footer);
            if (b == -1) { throw new Exception("Invalid pem file. Footer " + footer + " not found."); }

            string certString = pem.Substring(a, (b + footer.Length - a));
            certString = certString.Replace("\n", "");

            return encoding.GetBytes(certString);
        }

        public static byte[] GetCertificate(string pem, Encoding encoding)
        {
            if (encoding == null) { encoding = Encoding.ASCII; }

            string header = "-----BEGIN CERTIFICATE-----";
            string footer = "-----END CERTIFICATE-----";

            int a = pem.IndexOf(header);
            if (a == -1) { throw new Exception("Invalid pem file. Header " + header + " not found."); }
            int b = pem.IndexOf(footer);
            if (b == -1) { throw new Exception("Invalid pem file. Footer " + footer + " not found."); }

            string certString = pem.Substring(a, (b + footer.Length - a));
            certString = certString.Replace("\n", "");

            return encoding.GetBytes(certString);
        }

        public static async Task<JwtSecurityToken> TokenRequest(string tenantId, string clientId, string clientSecret)
        {
            string graphAPITokenEndpoint = "https://login.microsoftonline.com/" + tenantId + "/oauth2/v2.0/token";

            string body = GetTokenRequestBody(clientId, clientSecret);
            var results = await MyHttpClient.TokenRequest(graphAPITokenEndpoint, body);
         
            JObject j = JObject.Parse(results);
            if (string.IsNullOrWhiteSpace(j["access_token"] + "")) { throw new Exception(results); }

            var jwtHandler = new JwtSecurityTokenHandler();
            JwtSecurityToken token = jwtHandler.ReadJwtToken(j["access_token"] + "");

            return token;
        }

        public static async Task<JwtSecurityToken> TokenRequest(string pem, string tenantId, string clientId, int expSeconds, string? jwtId)
        {
            string graphAPITokenEndpoint = "https://login.microsoftonline.com/" + tenantId + "/oauth2/v2.0/token";

            string body = GetTokenRequestBody(pem, tenantId, clientId, expSeconds, jwtId);
            var results = await MyHttpClient.TokenRequest(graphAPITokenEndpoint, body);

            JObject j = JObject.Parse(results);
            if (string.IsNullOrWhiteSpace(j["access_token"] + "")) {throw new Exception(results);}

            var jwtHandler = new JwtSecurityTokenHandler();
            JwtSecurityToken token = jwtHandler.ReadJwtToken(j["access_token"] + "");

            return token;
        }

        public static string GetTokenRequestBody(string clientId, string clientSecret)
        {
            string data = "" +
"\nclient_id=" + clientId +
"\n&scope=" + System.Web.HttpUtility.UrlEncode("https://graph.microsoft.com/.default") +
"\n&client_secret=" + clientSecret +
"\n&grant_type=client_credentials";

            return data;
        }

        public static string GetTokenRequestBody(string pem, string tenantId, string clientId,int expSeconds, string? jwtId) 
        {
            string graphAPITokenEndpoint = "https://login.microsoftonline.com/" + tenantId + "/oauth2/v2.0/token";

            Encoding encoding = Encoding.ASCII;
            DateTime now = DateTime.Now;
            
      
            List<string> segments = new List<string>();

            //byte[] pemBytes = GetCertificate(pem, encoding);
            //var x509 = new X509Certificate2(pemBytes);
            var x509 = PemToX509(pem, true, null);
            if (!x509.HasPrivateKey) { throw new Exception("Private key not found"); }
            var thumbprintBytes = Convert.FromHexString(x509.Thumbprint);
            string xt5base64 = Base64UrlEncode(thumbprintBytes);

            var header = new
            {
                alg = "RS256",
                typ = "JWT",
                x5t = xt5base64
            };

            long uNow = Convert.ToInt32(new DateTimeOffset(now).ToUniversalTime().ToUnixTimeSeconds());
            long exp = uNow + expSeconds;

            if (string.IsNullOrWhiteSpace(jwtId)) { jwtId = Guid.NewGuid().ToString(); }

            var payload = new
            {
                aud = graphAPITokenEndpoint,
                exp = exp,
                iss = clientId,
                jti = jwtId,
                nbf = uNow,
                sub = clientId,
                iat = uNow,
            };

            string jsonHeader = JsonConvert.SerializeObject(header, Formatting.None);
            string jsonPayload = JsonConvert.SerializeObject(payload, Formatting.None);

            byte[] headerBytes = encoding.GetBytes(jsonHeader);
            byte[] payloadBytes = encoding.GetBytes(jsonPayload);

            segments.Add(Base64UrlEncode(headerBytes));
            segments.Add(Base64UrlEncode(payloadBytes));


            string stringToSign = string.Join(".", segments.ToArray());
            byte[] bytesToSign = encoding.GetBytes(stringToSign);

            RsaKeyParameters rsaKeyParameters = null;
            using (TextReader textReader = new StringReader(pem))
            {
                Org.BouncyCastle.Utilities.IO.Pem.PemReader pemReader = new Org.BouncyCastle.Utilities.IO.Pem.PemReader(textReader);
                PemObject pemObject = pemReader.ReadPemObject();
                PrivateKeyInfo privateKeyInfo = PrivateKeyInfo.GetInstance(pemObject.Content);
                AsymmetricKeyParameter privateKeyBC = PrivateKeyFactory.CreateKey(privateKeyInfo);
                rsaKeyParameters = (RsaKeyParameters)privateKeyBC;
            }

            ISigner sig = SignerUtilities.GetSigner("SHA256withRSA");

            sig.Init(true, rsaKeyParameters);
            sig.BlockUpdate(bytesToSign, 0, bytesToSign.Length);
            byte[] signature = sig.GenerateSignature();
            segments.Add(Base64UrlEncode(signature));

            string client_assertion = string.Join(".", segments.ToArray());

            string data = "" +
    "scope=" + System.Web.HttpUtility.UrlEncode("https://graph.microsoft.com/.default") +
    "\n&client_id=" + clientId +
    "\n&client_assertion_type=" + System.Web.HttpUtility.UrlEncode("urn:ietf:params:oauth:client-assertion-type:jwt-bearer") +
    "\n&client_assertion=" + client_assertion +
    "\n&grant_type=client_credentials";

            return data;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="stringToSign"></param>
        /// <param name="encoding">stringToSign encoding</param>
        /// <param name="pemCertificate"></param>
        /// <param name="algorithm"></param>
        /// <param name="urlEncode"></param>
        /// <returns></returns>
        public static string SignBase64(string stringToSign,Encoding? encoding, string pemCertificate, string? algorithm, bool urlEncode) 
        {
            if (encoding == null) { encoding = Encoding.UTF8; }
            byte[] bytesToSign = encoding.GetBytes(stringToSign);
            byte[] signature = Sign(bytesToSign, pemCertificate, algorithm);
            if (urlEncode)
            {
                return Base64UrlEncode(signature);
            }
            else 
            {
                return Convert.ToBase64String(signature);
            }
        }

        public static byte[] Sign(byte[] bytesToSign, string pemCertificate, string? algorithm)
        {
            if (string.IsNullOrWhiteSpace(algorithm)) { algorithm = "SHA256withRSA"; }

            RsaKeyParameters rsaKeyParameters = null;
            using (TextReader textReader = new StringReader(pemCertificate))
            {
                Org.BouncyCastle.Utilities.IO.Pem.PemReader pemReader = new Org.BouncyCastle.Utilities.IO.Pem.PemReader(textReader);
                PemObject pemObject = pemReader.ReadPemObject();
                PrivateKeyInfo privateKeyInfo = PrivateKeyInfo.GetInstance(pemObject.Content);
                AsymmetricKeyParameter privateKeyBC = PrivateKeyFactory.CreateKey(privateKeyInfo);
                rsaKeyParameters = (RsaKeyParameters)privateKeyBC;
            }

            ISigner sig = SignerUtilities.GetSigner(algorithm);

            sig.Init(true, rsaKeyParameters);
            sig.BlockUpdate(bytesToSign, 0, bytesToSign.Length);
            byte[] signature = sig.GenerateSignature();

            return signature;
        }

        public static string Base64UrlEncode(byte[] input)
        {
            var output = Convert.ToBase64String(input);
            output = output.Split('=')[0]; // Remove any trailing '='s
            output = output.Replace('+', '-'); // 62nd char of encoding
            output = output.Replace('/', '_'); // 63rd char of encoding
            return output;
        }


        public static byte[] Base64UrlDecode(string input)
        {
            var output = input;
            output = output.Replace('-', '+'); // 62nd char of encoding
            output = output.Replace('_', '/'); // 63rd char of encoding
            switch (output.Length % 4) // Pad with trailing '='s
            {
                case 0: break; // No pad chars in this case
                case 2: output += "=="; break; // Two pad chars
                case 3: output += "="; break; // One pad char
                default: throw new System.Exception("Illegal base64url string!");
            }
            var converted = Convert.FromBase64String(output); // Standard base64 decoder
            return converted;
        }
    }
}
