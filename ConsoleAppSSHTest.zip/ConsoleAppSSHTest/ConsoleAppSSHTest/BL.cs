﻿using Npgsql;
using Renci.SshNet;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Runtime.Intrinsics.X86;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Newtonsoft.Json;
using System.Text.Json.Nodes;
using Newtonsoft.Json.Serialization;
using Newtonsoft.Json.Linq;
using System.Text.Json;
using System.Configuration;
using Npgsql.PostgresTypes;
using Microsoft.VisualBasic.FileIO;
using System.Xml.Linq;
using System.Linq.Expressions;
using System.Reflection.Metadata;

namespace ConsoleAppSSHTest
{
    internal class BL
    {
        public static void W(object s) { Console.WriteLine(s); }

        public static string GetAppSetting(string key)
        {
            string str = ConfigurationManager.AppSettings[key];
            if (string.IsNullOrWhiteSpace(str)) { W("AppSetting " + key + " is null or empty"); }
            return str;

        }

        public static void Import()
        {
            W("Import");
            int A = Environment.TickCount;

            string importFile = GetAppSetting("path");
            string connectionString = GetAppSetting("Import.ConnectionString");
            string importSqlTable = GetAppSetting("Import.SqlTable");
            W("path: " + importFile);

            string json = File.ReadAllText(importFile, Encoding.UTF8);
            JArray jArray = (JArray)JsonConvert.DeserializeObject(json);
            W("Rows: " + jArray.Count);

            int rows = 1000;
            using (var ssh = new SSHConnection())
            {
                NpgsqlConnection conn = null;

                //using (var conn = new NpgsqlConnection(connectionString))
                try
                {
                    conn = new NpgsqlConnection(connectionString);
                    W("ConnectionTimeout:" + conn.ConnectionTimeout);
                    conn.Open();

                    //string sqlTables = "select count(*) count from pg_catalog.pg_tables where tablename='" + importSqlTable + "'";
                    using (NpgsqlCommand command = new NpgsqlCommand())
                    {
                        command.Connection = conn;
                        NpgsqlDataReader reader;

                        command.CommandText = "select count(*) count from pg_catalog.pg_tables where tablename='" + importSqlTable + "'";
                        reader = command.ExecuteReader();

                        //list all tables 
                        //for (int i = 0; i < reader.FieldCount; i++)
                        //{
                        //    W(reader.GetName(i));
                        //}

                        Int64 count = 0;
                        while (reader.Read())
                        {
                            count = (Int64)reader["count"];
                        }
                        reader.Close();

                        if (count != 1)
                        {
                            W("Table " + importSqlTable + " not found");
                            reader.Close();
                            return;
                        }

                        command.CommandText = "select * from " + importSqlTable + " limit 1";
                        reader = command.ExecuteReader();

                        while (reader.Read())
                        {
                            W("Table " + importSqlTable + " is not empty. Only empty data table is allowed.");
                            return;
                        }

                        Dictionary<string, PostgresType> fieldTypes = new Dictionary<string, PostgresType>();
                        List<string> fields = new List<string>();
                        for (int j = 0; j < reader.FieldCount; j++)
                        {
                            string name = reader.GetName(j);
                            PostgresType pType = reader.GetPostgresType(j);
                            fields.Add(name);
                            fieldTypes.Add(name, pType);

                            //W(name + ":" + pType);
                        }
                        reader.Close();

                        NpgsqlTransaction tr = (NpgsqlTransaction)conn.BeginTransaction();

                        try
                        {
                            int A2 = Environment.TickCount;
                            List<string> valueRowsSql = new List<string>();
                            rows = jArray.Count;
                            //rows = 10;
                            command.Parameters.Clear();
                            for (int i = 0; i < rows; i++)
                            {

                                JObject jObj = (JObject)jArray[i];

                                List<string> valueRow = new List<string>();
                                foreach (string name in fields)
                                {
                                    JValue jValue = (JValue)jObj[name];

                                    PostgresType postgresType = fieldTypes[name];
                                    string parameterName = "@" + name + "_" + i;
                                    valueRow.Add(parameterName);

                                    //add parameter and value
                                    NpgsqlParameter parameter = ConvertToNpgsqlParameter(parameterName, jValue.Value, postgresType);
                                    command.Parameters.Add(parameter);

                                }
                                string valueRowString = "(" + string.Join(",", valueRow) + ")";
                                valueRowsSql.Add(valueRowString);


                                if (valueRowsSql.Count == 100 || i == rows - 1)
                                {
                                    //'Bulk' insert
                                    string sql = "insert into " + importSqlTable + " (" + string.Join(',', fields) + ") values \n" + string.Join(",\n", valueRowsSql);
                                    //W(sql);

                                    command.CommandText = sql;
                                    int commandCount = command.ExecuteNonQuery();
                                    //W("commandCount:" + commandCount);

                                    //clear parameters and valueRowsSql
                                    command.Parameters.Clear();
                                    valueRowsSql.Clear();
                                }

                                if (i % 1000 == 0) { W("Rows inserted:" + i + ", TickCount: " + (Environment.TickCount - A2)); }
                            }

                            W("Commit");
                            tr.Commit();
                        }
                        catch (Exception ex)
                        {
                            W("Rollback");
                            tr.Rollback();
                            throw ex;
                        }
      

                    }

                    conn.Close();
                }
                catch (Exception ex) 
                {
                    throw ex;
                }
                finally { 
                    if (conn != null) { conn.Close(); }
                }
            }

            W("Import Rows inserted: " + rows + " TickCount:" + (Environment.TickCount - A));
        }

        public static NpgsqlParameter ConvertToNpgsqlParameter(string parameterName, object value, PostgresType postgresType)
        {
            NpgsqlParameter parameter = new NpgsqlParameter(parameterName, postgresType);

            if (value == null) {
                parameter.Value = Convert.DBNull;
                return parameter;
            }

            switch (postgresType.Name)
            {
                case "character varying":
                    parameter.Value = Convert.ToString(value);
                    break;
                case "boolean":
                    parameter.Value = Convert.ToBoolean(value);
                    break;
                case "uuid":
                    parameter.Value = new Guid(value + "");
                    break;
                default:
                    throw new Exception("Unknown datatype " + postgresType + " value " + value);
            }

            return parameter;
        }

        public static void Export()
        {
            W("Export");
            int A = Environment.TickCount;

            W("SqlFile:" + GetAppSetting("Export.SqlFile"));
            
            string exportFile = GetAppSetting("path");
            string connectionString = GetAppSetting("Export.ConnectionString");
            string sql = File.ReadAllText(GetAppSetting("Export.SqlFile"),Encoding.UTF8);

            W("Path:" + exportFile);

            

            if (File.Exists(exportFile)) { 
                W("File " + exportFile + " already exist");
                return;
            }

            List<JObject> list = new List<JObject>();

            using (var ssh = new SSHConnection()) {

                //"Server=127.0.0.1;Port=15432;Database=dev1accountsdb;Timeout=30;Username=dev1accounts;Password=stnuocca1ved"
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    W("ConnectionTimeout:" + conn.ConnectionTimeout);
                    conn.Open();

                    //string sql = "SELECT id,pin,lastname,givenname,create_time,valid FROM person";
                    using (NpgsqlCommand command = new NpgsqlCommand(sql, conn))
                    {
                        NpgsqlDataReader reader = command.ExecuteReader();
                    
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            W(reader.GetName(i));
                        }

                        while (reader.Read())
                        {
                            JObject jObject = new JObject();
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                string name = reader.GetName(i);
                                object value = reader[i];
                                JToken jToken = JToken.FromObject(value);
                                jObject[name] = jToken;
                            }
                            list.Add(jObject);
                        }

                        reader.Close();
                    }

                    conn.Close();

                    string text = JsonConvert.SerializeObject(list);
                    File.WriteAllText(exportFile, text,Encoding.UTF8);
                }
            }

            W("Export Rows:" + list.Count  + ", TickCount:" + (Environment.TickCount - A));
        }
    }
}
