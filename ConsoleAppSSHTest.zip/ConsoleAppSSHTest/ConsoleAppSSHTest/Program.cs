﻿// See https://aka.ms/new-console-template for more information

if (Arguments.HasArgument(args, "-import")) 
{
    //ConsoleAppSSHTest.BL.Import();
    return;
}

if (Arguments.HasArgument(args, "-export"))
{
    //ConsoleAppSSHTest.BL.Export();
    return;
}

ConsoleAppSSHTest.BL.W("Invalid operation");


