﻿using Renci.SshNet;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppSSHTest
{
    internal class SSHConnection : IDisposable
    {
        public SshClient Client;
        public ForwardedPort ForwardedPort;

        public static void W(object s) { /*Console.WriteLine("[SSHConnection]" + s);*/ }

        public SSHConnection() 
        {
            Connect();
        }

        private void Connect()
        {
            W("Connect");
            Client = new SshClient("35.228.190.156", 12002, "petmie_cice_fi", new PrivateKeyFile(@"C:\Users\miettinenp\.ssh\google_compute_engine"));
            Client.Connect();

            ForwardedPort = new ForwardedPortLocal("127.0.0.1", 15432, "172.16.20.2", 5432);
            Client.AddForwardedPort(ForwardedPort);
            ForwardedPort.Start();
        }

        private void Disconnect()
        {
            W("Disconnect");
            if (ForwardedPort != null) { ForwardedPort.Stop(); }
            if (Client != null) { Client.Disconnect(); }
        }

        public void Dispose()
        {
            Disconnect();
        }
    }
}
