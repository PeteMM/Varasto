﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SshNet;
using Npgsql;
using Renci.SshNet;
using System.Runtime.Intrinsics.X86;
using System.Security.Authentication;
using System.Net;

namespace ConsoleAppSSHTest
{
    //https://stackoverflow.com/questions/75079244/how-to-set-connectionstring-for-postgres-in-c-sharp
    internal class Class1
    {
        public static void W(object s) { Console.WriteLine(s); }

        public static void Test() {
            W("Test");

            //System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
     
            using (var client = new SshClient("35.228.190.156",12002, "petmie_cice_fi", new PrivateKeyFile(@"C:\Users\miettinenp\.ssh\google_compute_engine")))
            {
                client.Connect();
                W("client:" + client.IsConnected +  ", " + client.ConnectionInfo.Host + ":" + client.ConnectionInfo.Port);

                var forwardedPort = new ForwardedPortLocal("127.0.0.1", 15432, "172.16.20.2", 5432);
                client.AddForwardedPort(forwardedPort);
                forwardedPort.Start();

                using (var conn = new NpgsqlConnection("Server=127.0.0.1;Port=15432;Database=dev1accountsdb;Timeout=30;Username=dev1accounts;Password=stnuocca1ved"))
                {
                    W("ConnectionTimeout:" + conn.ConnectionTimeout);
                    conn.Open();

                    string sql = "SELECT count(*) FROM person";
                    using (NpgsqlCommand command = new NpgsqlCommand(sql, conn))
                    {
                        NpgsqlDataReader reader = command.ExecuteReader();
                        while (reader.Read())
                        {
                            int val = Int32.Parse(reader[0].ToString());
                            W("val:" + val);
                        }
                    }

                    conn.Close();
                }

                forwardedPort.Stop();
                client.Disconnect();
            }

        }


    }
}
