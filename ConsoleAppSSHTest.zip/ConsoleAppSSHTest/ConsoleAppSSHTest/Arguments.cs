﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//namespace MyArguments
//{
    public class Arguments
    {
        public static bool HasArgument(string[] args, string argName)
        {
            int i = GetArgumentIndex(args, argName);
            return (i > -1 ? true : false);
        }

        public static int GetArgumentIndex(string[] args, string argName)
        {
            for (int i = 0; i < args.Length; i++)
            {
                if (args[i].ToLower() == argName.ToLower()) { return i; }
            }

            return -1;
        }

        public static string GetArgument(string[] args, int i)
        {
            if (i < args.Length)
            {
                return args[i];
            }

            return null;
        }

        public static string GetArgumentValue(string[] args, string argName)
        {
            int i = GetArgumentIndex(args, argName);
            if (i < 0) { throw new Exception("Argument " + argName + " not found."); }

            if (i > -1)
            {
                return GetArgument(args, i + 1);
            }

            return null;
        }

    }
//}
