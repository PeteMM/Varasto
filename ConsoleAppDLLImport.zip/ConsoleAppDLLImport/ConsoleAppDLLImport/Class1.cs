﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyModel;

namespace ConsoleAppDLLImport
{
    internal class Class1
    {
        public Class1()
        {
            string path = @"E:\Projects\ConsoleAppDLLImport\ClassLibrary1\bin\Debug\net7.0\ClassLibrary1.dll";

            Assembly assembly = null;
            
            //using (FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read)) 
            //{
            //    assembly = System.Runtime.Loader.AssemblyLoadContext.Default.LoadFromStream(fs);
            //}

            byte[] bytes =  File.ReadAllBytes(path);
            using (MemoryStream ms = new MemoryStream(bytes))
            {
                assembly = System.Runtime.Loader.AssemblyLoadContext.Default.LoadFromStream(ms);
            }

            //var assembly = System.Runtime.Loader.AssemblyLoadContext.Default.LoadFromAssemblyPath(path);

            Console.WriteLine(assembly.FullName);

            object? instance = assembly.CreateInstance("ClassLibrary1.Class1");
            Type t = instance.GetType();

            var methodInfo = t.GetMethod("RunStatic");
            methodInfo.Invoke(null, null);
        }

        public void Class1_OLD()
        {
            //ClassLibrary1.Class1.RunStatic();
            FileInfo fileInfo = new FileInfo(@"E:\Projects\ConsoleAppDLLImport\ClassLibrary1\bin\Debug\net7.0\ClassLibrary1.dll");
            AssemblyName assemblyName = new AssemblyName(fileInfo.Name.Replace(fileInfo.Extension, string.Empty));

            var dependencyContext = DependencyContext.Default;

            foreach (var a in dependencyContext.CompileLibraries)
            {
                Console.WriteLine(a.Name);
            }


            var ressource = dependencyContext.CompileLibraries.FirstOrDefault(r => r.Name.Contains(assemblyName.Name));
            if (ressource == null) 
            {
                Console.WriteLine("ressource == null");
            }

            if (ressource != null)
            {
                Console.WriteLine("Assembly.Load " + ressource.Name);
                Assembly assembly = Assembly.Load(new AssemblyName(ressource.Name));
                object? inctance = assembly.CreateInstance("ClassLibrary1.Class1");
                Type t = inctance.GetType();

                Console.WriteLine(inctance.GetType());

                //var firstInterfaceType = assembly.DefinedTypes.FirstOrDefault(t => t.IsInterface).GetType();
                //Console.WriteLine(firstInterfaceType);


                //var firstInterfaceImplementationType = assembly.DefinedTypes.Where(t => t.ImplementedInterfaces.Contains(firstInterfaceType)).GetType();
                //Console.WriteLine(firstInterfaceImplementationType);



                //var memberInfos = t.GetMembers();
                //foreach (MemberInfo memberInfo in memberInfos)
                //{
                //    Console.WriteLine(memberInfo.Name + " " + memberInfo.GetType());

                //}

                Console.WriteLine("Invoke:");
                var obj = t.InvokeMember("Run", 
                    BindingFlags.DeclaredOnly | BindingFlags.Public | BindingFlags.NonPublic |
                    BindingFlags.Instance | BindingFlags.InvokeMethod, null, inctance, null);

                var methodInfo = t.GetMethod("RunStatic");
                methodInfo.Invoke(null, null);

            }

        }
    }
}
