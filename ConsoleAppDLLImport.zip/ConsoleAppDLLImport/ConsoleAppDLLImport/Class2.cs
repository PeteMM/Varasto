﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppDLLImport
{
    internal class Class2
    {
        public static void W(object s)
        { 
            Console.WriteLine(s);
        }

        public static int RotateLeft(byte b) 
        {
            var a = b & 128;
            if (a == 128) {
                W(a);
                return (127 & b) << 1;
            }
            else {
                return b << 1;
            }
        
        }

        public static void Test()
        {
            //byte[] arr = new byte[] { 1, 2, 3, 4, 5, 6 };

            //byte b = 254;
            //W(Convert.ToString(b, toBase: 2).PadLeft(8, '0'));
            //W(129 & 128);
            //var a = b << 1;
            //W(Convert.ToString(a, toBase: 2).PadLeft(8,'0'));

            W(Convert.ToString(RotateLeft(128), toBase: 2).PadLeft(8, '0'));
         

        }
    }
}
