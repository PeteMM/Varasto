﻿// See https://aka.ms/new-console-template for more information
using ConsoleAppDLLImport;


//Console.WriteLine("Hello, World!");
//ConsoleAppDLLImport.Class1 class1 = new ConsoleAppDLLImport.Class1();


Class2.Test();