﻿namespace ClassLibrary1
{
    public class Class1
    {
        public void Run()
        {
            Console.WriteLine("ClassLibrary1.Class1.Run");
        }

        public static void RunStatic()
        {
            Console.WriteLine("ClassLibrary1.Class1.RunStatic");
        }

    }
}